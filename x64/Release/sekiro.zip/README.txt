The developer debug menu for Sekiro.

The debug menu font was cut from the game, so custom fonts had to be added. Huge thanks to Enlisted for practically making the entire draw function.

[USE]

Select = Show/Hide menu
RT + Right stick = Resize menu
RT + Left stick = Move menu
L3 + X = Freeze/Unfreeze camera
﻿L3 + A = Rotate camera

[INSTALLATION]

Simply drag and drop "d3d11.dll" into your Sekiro directory (where your .exe is located)

[UNINSTALLATION]

Delete "d3d11.dll" from your Sekiro directory.

[FAQ]

Q) What is it?
A) The developer's debug menu for the game, it includes so many options I can't list them here.

Q) 'X' crashes!
A) Let me know what crashes and I'll  have a look into it, this is the debug menu though, so some things will inevitably be removed.

Q) I can't see text on the GUI windows
A) That's still broken, I'll fix it later

Q) The text is flickering
A) We had to balance between refreshing the menu fast enough to keep it updated, and the flickering. It's still fairly bad but should be manageable for now.

[CREDITS]

Special thanks for Enlisted for helping me figure out the draw function.
Special thanks for Pav for restoring some of the menu drop-downs, he has requested a link to the ?ServerName? souls modding discord here: https://discord.gg/mT2JJjx